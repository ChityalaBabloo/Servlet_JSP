Note : Make Sure You Have A Working Internet Connection, A LocalServer And A Database.

Step 1: Open Tables.sql file Present in src(Sub-folder of Java Resources)
Step 2: Run SQL Command Line and Connect To the database Using Your Credentials
step 3: Follow the steps mentioned in Tables.sql file
step 4: Now, Open home.jsp file present in WebContent(Folder) through your Browser(Chrome/Firefox/Internet Explorer)